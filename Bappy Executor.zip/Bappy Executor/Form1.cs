﻿using QuorumAPI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BappyExecutor
{
    public partial class Form1 : Form
    {
        private QuorumModule quorum;
        private async Task<string> GetEditorContent()
        {
            await webView21.EnsureCoreWebView2Async();
            string script = "monaco.editor.getModels()[0].getValue()";
            string result = await webView21.ExecuteScriptAsync(script);
            return JsonSerializer.Deserialize<string>(result);
        }

        private async Task ExecuteScriptAsync()
        {
            string scriptcontent = await GetEditorContent();
            quorum.Execute(scriptcontent);
        }

        private async void Attachwithapi()
        {
            try
            {
                var proc = Process.GetProcessesByName("RobloxPlayerBeta").FirstOrDefault();
                if (proc == null)
                {
                    LogToConsole("Roblox isnt Running!", LogType.ERROR);
                    return;
                }
                if (quorum.IsPIDAttached(proc.Id))
                {
                    LogToConsole($"Already Injected into Roblox (PID: {proc.Id})", LogType.INFO);
                    return;
                }
                await quorum.Attach(proc.Id);
                LogToConsole($"Injected into Roblox (PID: {proc.Id})", LogType.Success);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Injection failed: {ex.Message}", "Error");
            }
        }


        private async Task CleaWhiteitor()
        {
            await webView21.ExecuteScriptAsync("editor.setValue('')");
        }

        private async Task SaveTextAsLua()
        {
            string scriptsPath = Path.Combine(System.Windows.Forms.Application.StartupPath, "Scripts");


            Directory.CreateDirectory(scriptsPath);

            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                InitialDirectory = scriptsPath,
                Filter = "Lua files (*.lua)|*.lua",
                DefaultExt = "lua",
                Title = "Save Lua File"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string content = await GetEditorContent();
                File.WriteAllText(saveFileDialog.FileName, content);
            }
        }

        private async Task LoadTextFromFile()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Lua files (*.lua)|*.lua",
                Title = "Open Lua File"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string content = File.ReadAllText(openFileDialog.FileName);
                await webView21.ExecuteScriptAsync($"editor.setValue(`{content}`);");
            }
        }

        private async void Startup()
        {
            try
            {
                string Exe = System.Reflection.Assembly.GetExecutingAssembly().Location;
                string dir = Path.GetDirectoryName(Exe);
                var files = Directory.GetFiles(dir);

                foreach (string file in files)
                {
                    try
                    {
                        // Removed: File.SetAttributes(file, File.GetAttributes(file) | FileAttributes.Hidden);
                        // Now it does nothing to the file attributes
                    }
                    catch { MessageBox.Show("Error on File configuration"); }
                }
            }
            catch { MessageBox.Show("Error on fetching files"); }

            quorum = new QuorumModule();
            quorum.StartCommunication();
            await webView21.EnsureCoreWebView2Async(null);
            webView21.CoreWebView2.Navigate(System.Windows.Forms.Application.StartupPath + "\\bin\\MonacoWithTabs\\monaco.html");
        }



        private void Minimize()
        {
            this.WindowState = FormWindowState.Minimized;
        }
        private void Exit()
        {
            System.Windows.Forms.Application.Exit();
        }

        public enum LogType
        {
            INFO,
            ERROR,
            Warning,
            Success
        }

        public static class ConsoleLogger
        {
            public static Color GetLogColor(LogType type)
            {
                if (type == LogType.INFO)
                    return Color.White;
                if (type == LogType.ERROR)
                    return Color.Red;
                if (type == LogType.Warning)
                    return Color.Yellow;
                if (type == LogType.Success)
                    return Color.Green;

                return Color.White;
            }
        }

        private void LogToConsole(string message, LogType type)
        {
            string timestamp = DateTime.Now.ToString("HH:mm");
            Color logColor = ConsoleLogger.GetLogColor(type);

            consoleBox.SelectionStart = consoleBox.TextLength;
            consoleBox.SelectionLength = 0;


            consoleBox.SelectionColor = logColor;
            consoleBox.AppendText($"[ {type} ]");


            consoleBox.SelectionColor = Color.White;
            consoleBox.AppendText($" [{timestamp}] ");


            consoleBox.SelectionColor = logColor;
            consoleBox.AppendText($"{message}\n");

            consoleBox.ScrollToCaret();
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void guna2Button9_Click(object sender, EventArgs e)
        {
            Exit();
        }

        private void guna2Button7_Click(object sender, EventArgs e)
        {
            Attachwithapi();
        }

        private async void guna2Button6_Click(object sender, EventArgs e)
        {
            await ExecuteScriptAsync();
        }

        private async void guna2Button4_Click(object sender, EventArgs e)
        {
            await LoadTextFromFile();
        }

        private async void guna2Button5_Click(object sender, EventArgs e)
        {
            await SaveTextAsLua();
        }

        private async void guna2Button3_Click(object sender, EventArgs e)
        {
            await CleaWhiteitor();
        }

        private void guna2Button8_Click(object sender, EventArgs e)
        {
            Minimize();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Startup();
        }
    }
}
